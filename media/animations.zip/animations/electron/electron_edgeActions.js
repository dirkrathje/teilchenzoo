
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 21350, function(sym,e){sym.play();});
//Edge binding end
})("stage");
   //Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'electron'
(function(symbolName){})("electron");
   //Edge symbol end:'electron'

   //=========================================================
   
   //Edge symbol: 'Preloader'
   (function(symbolName) {   
   
   })("Preloader");
   //Edge symbol end:'Preloader'

})(jQuery, AdobeEdge, "edgeComposition-electron");